bResolution = true;

bQuality = false;

bImage = false;

bColor = false;

bDarkness = true;

bTonersave = true;

bReprint = false;

bHighaltitude = false;

bPowersave = true;

bAboutButtons =  true;

bPaper = true;